package com.forum.units;

import java.util.Date;

import com.forum.util.Utility;

public abstract class AbstractEntity {

	private Date created;
	private long id;

	/**
	 *
	 * Write a method called getId that requires no parameters and
	 * returns the id of this Abstract entity
	 *
	 * @return the id of this Abstract entity
	 */
	// Please write code for the s method here

	public long getId() {  // return type->long and the method name is "getId"
		return id;  // returning the id which is in getId method .

	}


	/**
	 *
	 * Write a method called setId that takes in a parameter and
	 * sets the id of this Abstract entity to the parameter.
	 *
	 * This method should return void.
	 *
	 * @param id: the id of this Abstract entity
	 */
	// Please write code for the setId method here


	public void setId(long id) // This is setId method which is not returning any value and it id taking parameter.
	{
		this.id = id; //setting "id" of Abstract entity using "this keyword"
                       //this keyword is used here to avoid confusion between "Global & Local" variables.
	}

	/**
	 *
	 * Write an abstract method called autoGenerateId.
	 *
	 *
	 * This method doesn't require any parameters and returns void
	 *
	 */
	// Please write code for the autoGenerateId abstract method here
	abstract void autoGenerateId();  /*Created an "abstract" method named "autoGenerateId" with no parameters
	                         and also their is no body for this because abstract methods don't have "body"*/




	public Date getCreated() {
		return created;
	}

	public void setCreated() {
		this.created = Utility.getCurrentDate();
	}
}
