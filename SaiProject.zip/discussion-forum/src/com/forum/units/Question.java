package com.forum.units;

public class Question extends AbstractEntity {

	//brief description of question
	private String title;
	//detail question
	private String message;
	//user who asked the question
	private User user;
	//number of upvotes for the question.
	private int upvoteCount = 0;
	//id of the last question asked on discussion forum
	private static Long lastEntry = 0L;

	public void autoGenerateId() {
		lastEntry = lastEntry + 1L;
		// please write your code below and follow this instruction:
		// 1. Call the parent class' setId method and pass in lastEntry as the method variable;

		super.setId(lastEntry); /*calling the parent class & setId method using "SUPER" keyword
		                        and passing the argument named "lastEntry" in it.
		                       Super keyword-->It is a reference variable used to call immediate parent class object */
	}

	public String getTitle() {
		return title; //returning/getting the instance variable named as title from getTitle method & return type is String
		              //getting/returning the values/variables by using "Getters"
	}

	public void setTitle(String title) {
		this.title = title; /*Setting the instance variable title to title variable
		                       which passed into the setTitle method as argument
		                       this(keyword)-->refers to the current object in a method or constructor.*/
		                      //Setting the value/variables using "Setters"
	}

	public String getMessage()
	{
		return message; //returning/getting variable named as "message" & return type is String
	}

	public void setMessage(String message) {
		this.message = message;/*Setting the instance variable message to message variable
		               this(keyword)-->to avoid confusion between "GLOBAL" & "LOCAL" variable*/
	}

	public User getUser() {
		return user;//returning/getting variable named as "user"
	}

	public void setUser(User user) {
		this.user = user;//Setting the instance variable user to user variable
	}

	public int getUpvoteCount() {
		return upvoteCount;//return upVoteCount
	}

	public void increaseUpvoteCount() {
		this.upvoteCount = this.upvoteCount + 1; // increasing upVoteCount by 1
	}

}
