package com.forum.units;

public class Reply extends AbstractEntity {

	//reply body
	private String message;
	//user who replied to the question
	private User user;
	//question for which user has replied
	private Question question;
	//id of the last reply posted on discussion forum
	private static Long lastEntry = 0L;

	public void autoGenerateId() {
		lastEntry = lastEntry + 1L;

		// please write your code below and follow this instruction:
		// 1. Call the parent class' setId method and pass in lastEntry as the method variable;
		// Note: You can read the setId method in the AbstractEntity class to understand how the setId method works
		super.setId(lastEntry); /*calling the parent class & setId method using "SUPER" keyword
		                        and passing the argument named "lastEntry" in it.
		                       Super keyword-->It is a reference variable used to call immediate parent class object */

	}

	/**
	 * This method returns the reply body
	 *
	 * @return the reply body
	 */
	public String getMessage() { //return type-->String
		// please write your code here
		// You should return the instance variable message
		return message; //returning the instance variable(using-getters) named "message" & return type is String
	}

	/**
	 * This method sets the body of the reply
	 *
	 * @param message: the message that we want to set as the reply body
	 */
	public void setMessage(String message) {
		// please write your code here
		// You should set the instance variable message to the
		// message variable that's passed into this function
		this.message = message; /*Setting the instance variable message to message variable(Using-setters)
		                       which passed into the setMessage method as argument
		                       this(keyword)-->refers to the current object in a method or constructor.*/
	}

	/**
	 * This method returns the user who wrote the reply
	 *
	 * @return the user who wrote this reply
	 */
	public User getUser() {
		// please write your code here
		// You should return the user instance variable
		return user; //returning the variable named as "user" from getUser method.
	}

	/**
	 * This method sets the user who wrote the reply
	 *
	 * @param user: the user who wrote this reply
	 */
	public void setUser(User user) {
		// please write your code here
		// You should set the instance variable user to the user variable
		// that is passed into this method
		this.user = user;/*Setting the instance variable user to user variable
		               this(keyword)-->to avoid confusion between "GLOBAL" & "LOCAL" variable*/
	}

	/**
	 * This method returns the question that this reply belongs to
	 *
	 * @return the question to which this reply belongs to
	 */
	public Question getQuestion() {
		// please write your code here
		// You should set the instance variable question
		return question; //returning question variable from getQuestionMethod
	}

	/**
	 * This method sets the question that this reply belongs to
	 *
	 * @param question: the question that this reply belongs to
	 */
	public void setQuestion(Question question) {
		// please write your code here
		// You should set the instance variable question to the question variable
		// that is passed into this method
		this.question = question; /*Setting the instance variable question to question variable
		                       which passed into the setQuestion method as argument
		                   */

	}
}
